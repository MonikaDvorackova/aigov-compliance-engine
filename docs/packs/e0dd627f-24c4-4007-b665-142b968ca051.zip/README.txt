AIGov evidence pack

run_id=e0dd627f-24c4-4007-b665-142b968ca051
policy_version=unknown

Contents
- bundle.json: machine verifiable evidence bundle
- report.md: human readable audit report
- policy.txt: policy snapshot reference
- manifest.json: sha256 for each file in this pack

Verification
1) Check manifest.json hashes match files
2) Optionally verify audit log chain with the governance server
