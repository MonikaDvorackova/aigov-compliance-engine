AIGov evidence pack

run_id=db2f0569-08ea-432e-8d8d-bf70750bc9a9
policy_version=unknown

Contents
- bundle.json: machine verifiable evidence bundle
- report.md: human readable audit report
- policy.txt: policy snapshot reference
- manifest.json: sha256 for each file in this pack

Verification
1) Check manifest.json hashes match files
2) Optionally verify audit log chain with the governance server
