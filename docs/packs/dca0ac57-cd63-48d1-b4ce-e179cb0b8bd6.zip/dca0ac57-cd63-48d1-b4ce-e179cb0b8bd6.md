run_id=dca0ac57-cd63-48d1-b4ce-e179cb0b8bd6
bundle_sha256=
policy_version=v0.4_human_approval

# Audit report for run `dca0ac57-cd63-48d1-b4ce-e179cb0b8bd6`

This PR changes compliance plumbing and evidence gating. Evidence attached.
