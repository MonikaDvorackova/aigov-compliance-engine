AIGov evidence pack

run_id=9baab928-90d9-4ad8-a211-3dc18108371e
policy_version=unknown

Contents
- bundle.json: machine verifiable evidence bundle
- report.md: human readable audit report
- policy.txt: policy snapshot reference
- manifest.json: sha256 for each file in this pack

Verification
1) Check manifest.json hashes match files
2) Optionally verify audit log chain with the governance server
