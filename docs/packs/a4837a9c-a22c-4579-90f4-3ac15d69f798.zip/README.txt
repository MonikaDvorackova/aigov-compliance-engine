AIGov evidence pack

run_id=a4837a9c-a22c-4579-90f4-3ac15d69f798
policy_version=unknown

Contents
- bundle.json: machine verifiable evidence bundle
- report.md: human readable audit report
- policy.txt: policy snapshot reference
- manifest.json: sha256 for each file in this pack

Verification
1) Check manifest.json hashes match files
2) Optionally verify audit log chain with the governance server
